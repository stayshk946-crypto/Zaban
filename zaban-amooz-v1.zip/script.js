const questions=[
 {q:"Hello یعنی چه؟",a:["خداحافظ","سلام","ممنون","شب بخیر"],c:1,e:"Hello برای سلام کردن استفاده می‌شود."},
 {q:"Book یعنی چه؟",a:["قلم","کتاب","مدرسه","خانه"],c:1,e:"Book یعنی کتاب."},
 {q:"I am a student یعنی چه؟",a:["من معلم هستم.","من دانش‌آموز هستم.","من پزشک هستم.","من دوست هستم."],c:1,e:"Student یعنی دانش‌آموز."},
 {q:"I ___ happy.",a:["am","is","are","be"],c:0,e:"با I از am استفاده می‌کنیم."},
 {q:"Thank you یعنی چه؟",a:["لطفاً","متأسفم","متشکرم","صبح بخیر"],c:2,e:"Thank you یعنی متشکرم."}
];
const words=[
 ["Hello","سلام","en-US"],["Book","کتاب","en-US"],["Student","دانش‌آموز","en-US"],
 ["School","مدرسه","en-US"],["Friend","دوست","en-US"],["Thank you","متشکرم","en-US"]
];
let state=JSON.parse(localStorage.getItem("zabanAmoz")||"{}");
state={xp:0,streak:0,correct:0,words:0,name:"زبان‌آموز",theme:"light",...state};
let qi=0;

const $=s=>document.querySelector(s);
function save(){localStorage.setItem("zabanAmoz",JSON.stringify(state));updateStats()}
function updateStats(){
 $("#xp").textContent=state.xp; $("#streak").textContent=state.streak;
 $("#level").textContent=Math.floor(state.xp/100)+1;
 $("#pXp").textContent=state.xp; $("#pCorrect").textContent=state.correct; $("#pWords").textContent=state.words;
 $("#nameInput").value=state.name;
}
function showScreen(id){
 document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));
 $("#"+id).classList.add("active");
 document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.screen===id));
 window.scrollTo(0,0);
 if(id==="quiz") renderQuestion();
}
document.querySelectorAll("[data-screen]").forEach(b=>b.addEventListener("click",()=>showScreen(b.dataset.screen)));

function toast(msg){
 const t=$("#toast"); t.textContent=msg; t.classList.add("show");
 setTimeout(()=>t.classList.remove("show"),1800);
}
function renderQuestion(){
 const x=questions[qi]; $("#questionText").textContent=x.q; $("#quizProgress").textContent=`${qi+1} / ${questions.length}`;
 $("#progressBar").style.width=`${((qi+1)/questions.length)*100}%`;
 $("#feedback").className="feedback hidden"; $("#nextBtn").classList.add("hidden");
 const box=$("#answers"); box.innerHTML="";
 x.a.forEach((ans,i)=>{
   const b=document.createElement("button"); b.className="answer"; b.textContent=ans;
   b.onclick=()=>answer(i); box.appendChild(b);
 });
}
function answer(i){
 const x=questions[qi]; const buttons=[...document.querySelectorAll(".answer")];
 buttons.forEach(b=>b.disabled=true);
 buttons[x.c].classList.add("correct");
 const f=$("#feedback"); f.classList.remove("hidden");
 if(i===x.c){
   state.xp+=10; state.correct++; state.words=Math.max(state.words, state.correct);
   f.className="feedback good"; f.innerHTML="🎉 <b>آفرین!</b> پاسخ درست بود.<br>⭐ +10 XP<br>💡 "+x.e;
   toast("عالی بود! 🎉 +10 XP");
 }else{
   buttons[i].classList.add("wrong");
   f.className="feedback bad"; f.innerHTML="🌱 <b>اشکالی نداره!</b> اشتباه کردن بخشی از یادگیریه.<br>✅ جواب درست: <b>"+x.a[x.c]+"</b><br>💡 "+x.e;
   toast("دوباره تلاش کن! 💪");
 }
 save(); $("#nextBtn").classList.remove("hidden");
}
$("#nextBtn").onclick=()=>{
 qi=(qi+1)%questions.length; renderQuestion();
 if(qi===0) toast("آزمون دوباره از اول شروع شد! 🏆");
};
$("#themeBtn").onclick=()=>{
 state.theme=state.theme==="dark"?"light":"dark";
 document.body.classList.toggle("dark",state.theme==="dark");
 $("#themeBtn").textContent=state.theme==="dark"?"☀️":"🌙"; save();
};
$("#saveProfile").onclick=()=>{state.name=$("#nameInput").value.trim()||"زبان‌آموز";save();toast("پروفایل ذخیره شد ✅")};
document.querySelectorAll(".speak").forEach(b=>b.onclick=()=>{
 if("speechSynthesis" in window){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(b.dataset.text);u.lang=b.dataset.lang;speechSynthesis.speak(u)}
 else toast("تلفظ در این مرورگر پشتیبانی نمی‌شود.");
});
$("#changeLanguage").onclick=()=>toast("در نسخه بعدی، زبان‌های بیشتری اضافه می‌کنیم 🌍");

$("#wordList").innerHTML=words.map(w=>`<div class="word"><div><b>${w[0]}</b><small>${w[1]}</small></div><button class="speak" data-text="${w[0]}" data-lang="${w[2]}">🔊</button></div>`).join("");
document.querySelectorAll("#wordList .speak").forEach(b=>b.onclick=()=>{
 if("speechSynthesis" in window){const u=new SpeechSynthesisUtterance(b.dataset.text);u.lang=b.dataset.lang;speechSynthesis.speak(u)}
});
if(state.theme==="dark"){$("body").classList.add("dark");$("#themeBtn").textContent="☀️"}
updateStats();